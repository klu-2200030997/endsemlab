package com.klef.jfsd.exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemendlabApplication {

	public static void main(String[] args) {
		SpringApplication.run(SemendlabApplication.class, args);
	}

}
